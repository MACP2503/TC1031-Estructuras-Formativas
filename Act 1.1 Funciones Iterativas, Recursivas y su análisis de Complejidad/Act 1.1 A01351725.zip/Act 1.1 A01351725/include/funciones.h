#ifndef FUNCIONES_H
#define FUNCIONES_H


class funciones
{
    public:
        funciones();
        ~funciones();
        int sumaIterativa(int);
        int sumaRecursiva(int);
        int sumaDirecta(int);
};

#endif // FUNCIONES_H
